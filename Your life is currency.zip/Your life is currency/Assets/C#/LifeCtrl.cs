﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LifeCtrl : MonoBehaviour {

	public int life;
	public GameObject[] lifeGroup;


	void Awake()
	{
		life = 8;
	}

	
	void Start () {
		
	}
	
	void Update () {
		if(life > 10)
		{
			life = 10;
		}

		UpdateLife();

		if(life <= 0)
		{
			SceneManager.LoadScene("end");
		}
		
	}

	
	public void UpdateLife()
	{
		for (int i = 0; i < lifeGroup.Length; i++)
		{
			if(i <= life - 1)
			{
				lifeGroup[i].SetActive(true);
			}else
			{
				lifeGroup[i].SetActive(false);
			}
		}
	}
}
