﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerTransform : MonoBehaviour {

	public Rigidbody2D r_rigidbody2D;


	void Start () {
		r_rigidbody2D = GetComponent<Rigidbody2D>();
	}

	void Update () {

		transform.localEulerAngles = Vector3.zero;
		
	}
}
