﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtetsCtrl : MonoBehaviour {

	PlayerCtrl player;

	void Awake()
	{
		Invoke("DestroyButtet",3f);
	}

	
	void Start () {
		player = GameObject.Find("Robot").GetComponent<PlayerCtrl>();
	}
	
	
	void Update () {
		
	}

	void OnTriggerEnter2D(Collider2D collider)
	{
		if(collider.tag == "wall")
		Destroy(this.gameObject);

		if(collider.tag == "Enemy")
		{
			collider.GetComponent<EnemyCtrl>().hp -= player.act;
			Debug.Log("Hit");
			Destroy(this.gameObject);
		}
	}

	public void DestroyButtet()
	{
		Destroy(this.gameObject);
		//Debug.Log("0");
	}

	
}
