﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PillarCtrl : MonoBehaviour {

	public Transform[] pillarPos;
	public GameObject pillar;
	
	void Start () {
		
	}
	
	
	void Update () {
		
	}
}
