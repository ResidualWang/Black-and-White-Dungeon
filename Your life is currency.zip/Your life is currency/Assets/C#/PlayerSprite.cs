﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSprite : MonoBehaviour {

	public Vector3 mousePosition;
	public SpriteRenderer spriteRenderer;
	public Sprite forword;
	public Sprite back;
	public Sprite left;
	public Sprite right;

	void Awake()
	{
		//forword = Resources.Load("Sprite/robotforward") as Sprite;
	}

	void Start () {
		spriteRenderer = GetComponent<SpriteRenderer>();
		//forword = Resources.Load("Sprite/robotforward") as Sprite;
	}
	
	void Update () {
		//获取鼠标位置;
		mousePosition = Input.mousePosition;
		//Debug.Log(mousePosition);

		//向左
		if(mousePosition.y > 400f && mousePosition.y < 700f && mousePosition.x < 930){
			spriteRenderer.sprite = left;
		}
		//向右
		if(mousePosition.y > 400f && mousePosition.y < 700f && mousePosition.x > 930){
			spriteRenderer.sprite = right;
		}
		//向上
		if(mousePosition.x > 800 && mousePosition.x < 1050 && mousePosition.y > 560){
			spriteRenderer.sprite = back;
		}
		//向下
		if(mousePosition.x > 800 && mousePosition.x < 1050 && mousePosition.y < 560){
			spriteRenderer.sprite = forword;
		}
	}
}
