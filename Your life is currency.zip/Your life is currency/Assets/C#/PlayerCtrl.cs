﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCtrl : MonoBehaviour {

	public float FireRate;
	public float BulletSpeed;
	public float act;

	void Awake()
	{
		FireRate = 0.36f;
        BulletSpeed = 8.6f;
		act = 1;
	}

	
	void Start () {
		
	}
	
	
	void Update () {

		if(act <= 0.1f)
		{
			act = 0.1f;
		}
		if(FireRate <= 0.1f)
		{
			FireRate = 0.1f;
		}
		
	}
}
