﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAct : MonoBehaviour {

	public GameObject bullet;
	public Transform playerPos;
	public float BulletSpeed;
	public float fireWait;

	void Awake()
	{
		InvokeRepeating("Fire",1,fireWait);
	}

	
	void Start () {
		playerPos = GameObject.Find("Robot").transform;
	}

	public void Fire()
	{
		float m_fireAngle = Vector2.Angle(playerPos.position - this.transform.position, Vector2.up);
 
        if(playerPos.position.x>this.transform.position.x)
        {
                m_fireAngle = -m_fireAngle;
        }

		GameObject m_bullet = Instantiate(bullet, transform.position, Quaternion.identity) as GameObject;
 
        // 速度
        m_bullet.GetComponent<Rigidbody2D>().velocity = ((playerPos.position-transform.position).normalized * BulletSpeed );
 
        // 角度
        m_bullet.transform.eulerAngles = new Vector3(0, 0, m_fireAngle);
	}
}
