﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBullets : MonoBehaviour {

	public int actValue;

	void Awake()
	{
		actValue = 1;
	}

	void OnTriggerEnter2D(Collider2D collider)
	{
		if(collider.tag == "wall")
		Destroy(this.gameObject);

		if(collider.tag == "Player")
		{
			GameObject.Find("LifeGroup").GetComponent<LifeCtrl>().life -= actValue;
			Destroy(this.gameObject);
		}
	}

	
}
