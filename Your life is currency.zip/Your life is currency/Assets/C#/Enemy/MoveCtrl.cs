﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveCtrl : MonoBehaviour {

	public Transform[] movePos;
	public Transform oldPos;
	public float speed;
	public float moveWait;

	void Awake()
	{
		InvokeRepeating("Move",0f,moveWait);
	}
	
	void Update () {

		Vector3 offSet = oldPos.position - transform.position;
        transform.position += offSet.normalized * speed * Time.deltaTime;
        if(Vector3.Distance(oldPos.position, transform.position)<0.1f)
        {
            transform.position = oldPos.position;
        }
		//transform.position = Vector2.Lerp(transform.position,oldPos.position, speed * Time.deltaTime);
		transform.localEulerAngles = Vector3.zero;
		
	}

	public void Move()
	{
		Transform pos = movePos[Random.Range(0,movePos.Length)];
		if(pos == oldPos)
		{
			Move();
			return;
		}
		oldPos = pos;
	}
}
