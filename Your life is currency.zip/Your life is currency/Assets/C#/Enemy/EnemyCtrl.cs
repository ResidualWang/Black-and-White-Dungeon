﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyCtrl : MonoBehaviour {

	public float hp;
	
	void Start () {
		
	}
	
	void Update () {

		if(hp <= 0)
		{
			Destroy(gameObject);
		}
		
	}
}
