﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreatCtrl : MonoBehaviour {

	public List<Transform> creatPos;
	public GameObject[] EnemyGroup;
	public BossGroup boss;
	public Transform[] movePos;
	public Transform bossPos;
	public Transform[] bossMove;

	void Start()
	{
		boss = GameObject.Find("Robot").GetComponent<BossGroup>();
	}

	public void Boss(int hp)
	{
		int a = Random.Range(0,creatPos.Count);
		GameObject enemy = Instantiate(boss.bossGroup[Random.Range(0,boss.bossGroup.Count)],bossPos.position,Quaternion.identity);
		GameObject.Find("Robot").GetComponent<BossGroup>().bossGroup.Remove(boss.bossGroup[a]);
		enemy.GetComponent<EnemyCtrl>().hp = hp;
		enemy.GetComponent<MoveCtrl>().movePos = bossMove;
	}

	public void Creat(int hp)
	{
		int a = Random.Range(0,creatPos.Count);
		GameObject enemy = Instantiate(EnemyGroup[Random.Range(0,EnemyGroup.Length)],creatPos[a].position,Quaternion.identity);
		creatPos.Remove(creatPos[a]);
		enemy.GetComponent<EnemyCtrl>().hp = hp;
		enemy.GetComponent<MoveCtrl>().movePos = movePos;
	}
}
