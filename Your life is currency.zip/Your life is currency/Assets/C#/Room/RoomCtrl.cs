﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomCtrl : MonoBehaviour {


	public GameObject door1;
	public GameObject door2;

	public bool isStart;

	public int room;

	void Update()
	{
		GameObject[] enmeyGroup = GameObject.FindGameObjectsWithTag("Enemy");

		if(isStart)
		{
			if(enmeyGroup.Length == 0)
			{
			    door1.SetActive(false);
		        door2.SetActive(false);
			}
		}
	}


	void OnTriggerEnter2D(Collider2D collider)
	{
		if(collider.name == "Robot")
		{
			//Debug.Log("1");
		    door1.SetActive(true);
		    door2.SetActive(true);
		    CreatEnemy();
			isStart = true;
		}

	}

	public void CreatEnemy()
	{
		if(!isStart)
		{
			if(room == 2)
			{
				GetComponent<CreatCtrl>().Boss(50);
			}
			if(room == 4)
			{
				GetComponent<CreatCtrl>().Boss(100);
			}
			if(room == 6)
			{
				GetComponent<CreatCtrl>().Boss(200);
			}
			if(room == 8)
			{
				GetComponent<CreatCtrl>().Boss(300);
			}
			if(room == 1)
			{
				GetComponent<CreatCtrl>().Creat(6);
		        GetComponent<CreatCtrl>().Creat(6);
		        GetComponent<CreatCtrl>().Creat(3);
		        GetComponent<CreatCtrl>().Creat(3);
			}
			if(room == 3)
			{
				GetComponent<CreatCtrl>().Creat(12);
		        GetComponent<CreatCtrl>().Creat(12);
		        GetComponent<CreatCtrl>().Creat(12);
		        GetComponent<CreatCtrl>().Creat(12);
			}
			if(room == 5)
			{
				GetComponent<CreatCtrl>().Creat(20);
		        GetComponent<CreatCtrl>().Creat(20);
		        GetComponent<CreatCtrl>().Creat(20);
		        GetComponent<CreatCtrl>().Creat(20);
				GetComponent<CreatCtrl>().Creat(20);
			}
			if(room == 7)
			{
				GetComponent<CreatCtrl>().Creat(30);
		        GetComponent<CreatCtrl>().Creat(30);
		        GetComponent<CreatCtrl>().Creat(30);
		        GetComponent<CreatCtrl>().Creat(30);
				GetComponent<CreatCtrl>().Creat(30);
			}
		}
	}

}
