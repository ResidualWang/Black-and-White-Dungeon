﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SightCtrl : MonoBehaviour {

	public Texture2D texture;
	
	void Start () {
		Cursor.SetCursor(texture,new Vector2(45,45),CursorMode.Auto);
	}
	
}
