﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Item9 : MonoBehaviour {

	public Text text;
	public GameObject TextBack;
	public PlayerCtrl player;

	void Start()
	{
		TextBack = GameObject.Find("Canvas").transform.Find("Image").gameObject;
		text = TextBack.transform.Find("Text").GetComponent<Text>();
		player = GameObject.Find("Robot").GetComponent<PlayerCtrl>();
	}

	void OnTriggerStay2D(Collider2D collider)
	{
		if(collider.name == "Robot")
		{
			text.text =  "Mysterious Capsule No. 5, Machine Gun-like Bullets";
			TextBack.SetActive(true);
			if(Input.GetKey(KeyCode.E))
			{
				Destroy(gameObject);
			    GameObject.Find("LifeGroup").GetComponent<LifeCtrl>().life -= 1;
				player.FireRate = 0.1f;
				player.BulletSpeed += 0.8f;
				player.act -= 0.75f;
				TextBack.SetActive(false);
			}
		}
	}
	void OnTriggerExit2D(Collider2D collider)
	{
		if(collider.name == "Robot")
		{
			TextBack.SetActive(false);
		}
	}
}
