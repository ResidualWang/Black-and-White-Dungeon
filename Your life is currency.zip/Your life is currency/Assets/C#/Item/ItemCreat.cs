﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemCreat : MonoBehaviour {

	public GameObject[] ItemGroup;

	void Awake()
	{
		Instantiate(ItemGroup[Random.Range(0,ItemGroup.Length)],transform.position,Quaternion.identity);
	}

}
