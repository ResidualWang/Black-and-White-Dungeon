﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Item11 : MonoBehaviour {

	public Text text;
	public GameObject TextBack;
	public PlayerCtrl player;

	void Start()
	{
		TextBack = GameObject.Find("Canvas").transform.Find("Image").gameObject;
		text = TextBack.transform.Find("Text").GetComponent<Text>();
		player = GameObject.Find("Robot").GetComponent<PlayerCtrl>();
	}

	void OnTriggerStay2D(Collider2D collider)
	{
		if(collider.name == "Robot")
		{
			text.text =  "Mysterious Capsule No. 3, with infinite strength";
			TextBack.SetActive(true);
			if(Input.GetKey(KeyCode.E))
			{
				Destroy(gameObject);
			    GameObject.Find("LifeGroup").GetComponent<LifeCtrl>().life -= 1;
				player.act += 0.5f;
				TextBack.SetActive(false);
			}
		}
	}
	void OnTriggerExit2D(Collider2D collider)
	{
		if(collider.name == "Robot")
		{
			TextBack.SetActive(false);
		}
	}
}
